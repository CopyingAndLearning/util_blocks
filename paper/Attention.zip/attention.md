## Attention is All You Need🤖

[paper](https://proceedings.neurips.cc/paper/2017/file/3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf)

#### 如何看论文

⭐⭐⭐看论文中形成自己的问题，这些问题都是独一无二的，要去自己思考并去解决自己的问题，这才是读研的目的

##### 看论文的方法

* 论文的方法论不是固定的，而是灵活的，根据不同时期的不同需要去看论文；
  把论文学习方法分为以下几个阶段：(尽量看有代码的)
  * ⭐基础阶段：先看摘要 → 再看引言 → 相关工作 → 最后看架构代码和实现方法；
  * ⭐进阶阶段：从论文（不要局限本领域❗，做CV的也可以看NLP的论文）的实际角度出发，抽象出这篇论文所对应核心思想，并迁移到自己的领域做到活学活用，同时也要看实验；
* 论文中的数学、思想、架构图、代码看不懂的都可以问AI；
  prompt：这个内容我不会，能够我通俗点解释一下吗？
  (重点在于通俗点的解释，直到自己能够理解🤨，不懂就一直问AI)
* 每个人的理解方式不一样，适合自己的理解方式最好；

##### 看论文的工具

* 翻译软件：推荐使用网易有道翻译，可以截图翻译和Snipaste结合起来用，效果挺好的🎯；
* 论文网站：(⭐越多，表示自己越常用的)
  * ⭐⭐[谷歌学术](https://scholar.google.com/)、[arxiv](https://arxiv.org/search/cs)
  * [openaccess](https://openaccess.thecvf.com/menu)  主要是一些顶会文章的汇总：CVPR、ICCV等计算机视觉相关的顶级会议；
    多数情况下，CV和NLP是互通的，可以看一些NeuralPS、AAAI对应的文章😀
  * ⭐大语言模型如：[kimi](https://kimi.moonshot.cn/)，[腾讯元宝-deepseek](https://yuanbao.tencent.com/chat/naQivTmsDa?yb_channel=3003)，ChatGPT
    提示词如下(prompt)：有没有目标检测的论文，给我推荐几篇，并给我它们的论文地址；
  * [论文关联性查询](https://www.connectedpapers.com/)
  * ⭐⭐[代码+论文](https://paperswithcode.com/)
    看有代码的论文，优先使用这个网站



#### Attention

* 使用基础阶段的阅读方法

##### 摘要

![image-20250425104535975](attention/image-20250425104535975.png)

【方法】

* 尽可能的用一句话或几句话描述这段内容，这样学习更高效😀

【概述】

1. 描述了一种编码器解码器架构；
2. 提出了注意力机制；
3. 训练的效果，以及训练资源和时间的；



##### 引言

引言就是为什么要提出这篇论文和这篇论文的研究目的

##### 相关工作

背景（background）某种程度上就是相关工作（related work)；



##### 架构和代码

###### 编码器解码器架构

* 编码器就是把人类能看懂的内容转变为计算机更能看懂且方便计算的内容，解码器就是把计算机能看懂的转换回来；
  ![image-20250425133810319](attention/image-20250425133810319.png)

整体架构：左边encoder，右边decoder

![image-20250425110123110](attention/image-20250425110123110.png)

###### 词向量化

* 这是NLP里面的内容，将非数值内容投影成为数值向量；
* https://www.bilibili.com/video/BV1vS4y1N7mo/
  这个课程通俗且详细说明了词向量化。

###### 输入嵌入——InputEmbedding

![image-20250425132647657](attention/image-20250425132647657.png)

* 一个词转换为向量，每一个分量都表示一定的信息。
  苹果 -> 假设：[红的，圆的] -> 投影成向量[0.5, 0.5]，这个0.5就反应了分量红的程度和分量圆的程度 -> 对红的程度这个分量进行投影就可以得到更多关于红色的信息，比如红色的色度等的，当然这是我们已知的特征，投影产生的其他维度包含非常抽象的信息，它不具有实际意义，主要是为了表示未知的抽象特征🤔

* 为什么要进行嵌入，其目的在于将分量投影到更高维的空间，以便于表示更多抽象特征；
  ``` python
  # 对得到的向量进行嵌入
  a = torch.randint(0,10,(5,10))
  print(a.shape)
  emb = nn.Embedding(10, 512)
  emba = emb(a)
  print(emba.shape)
  ```

  * a：是假设是经过向量化的文本内容：维度为[5,10]，表示有5个文本，每个文本有10个分量；
    randint表示生成0-10范围内形状为(5,10)的整数张量；

  * emb：每个分量嵌入的内容，是一个嵌入层；

  * emba：表示嵌入后的文本向量；

  * 整体过程🤔：
    输入向量a的维度为：[5,10]  -> emd [10,512] -> emba = [5,10,512]
    含义：a中的每条文本的每一个分量，都进行512维度的嵌入；
    更好的理解：张量[[4,5]]的维度为[1,2]，表示第一个维度只有一个数组，每个数组里面有两个元素，运行下面代码试试：

    ``` python
    print(torch.tensor[[4,5]].shape)
    ```

    所以，这里[5,10]表示有第一个维度有5个数组，每一个数组有10个元素，现在对这10个元素的每一个元素都嵌入到512维；
    [5,10] -> [ [], [], [], [], [] ] -> 里面的每一个[]都有10个元素[0,1,2,3,4,5,6,7,8,9]
    -> 嵌入过程：(0 -> [0,1, ... , 512]) , (1 -> [0,1, ... ,512]), ...., (9 -> [0,1, ... ,512])
    相当于将这10个元素的每一个元素都扩充到512维度，这里的数值只是举例不涉及具体的值；

###### 位置编码

![image-20250425132709454](attention/image-20250425132709454.png)

* 目的是为了加入位置关系，为了考虑文本的语序问题：
  例如：他爱她，她爱他。这两意思完全不一样；加入位置编码就是为了让模型拥有理解位置关系的能力；

* 是一个固定的公式，只需要记住会用代码就行：
  ![image-20250425124115665](attention/image-20250425124115665.png)

  ``` python
  class PositionalEncoding(nn.Module):
      def __init__(self, d_model, dropout=0.1, max_len=5000):
          super(PositionalEncoding, self).__init__()
          self.dropout = nn.Dropout(p=dropout)
  
          pe = torch.zeros(max_len, d_model)
          position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
          div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
          pe[:, 0::2] = torch.sin(position * div_term)
          pe[:, 1::2] = torch.cos(position * div_term)
          pe = pe.unsqueeze(0).transpose(0, 1)
          self.register_buffer('pe', pe)
  
      def forward(self, x):
          x = x + self.pe[:x.size(0), :]
          return self.dropout(x)
  ```

* ⭐torch用法等：

  * torch.zero：生成max_len,d_model的零矩阵；
  * torch.arange：生成torch类型的从0到512的数组；
  * unsqueeze(1)：表示升维，这里就是对torch.arange生成的每一个元素进行升维；
  * div_term：实现公式中括号里面的内容；
  * pe：对生成0数组进行切片赋值；
    [:, 0::2]：表示从0开始每个2个元素进行赋值，表示奇数列（从0开始❗），然后进行sin操作
    [:, 1::2]：表示从1开始每个2个元素进行赋值，表示偶数列（从1开始❗），然后进行cos操作
  * self.register_buffer：注册pe模块，方便前向过程调用；
  * :x.size(0)：表示截断，位置编码采用的最大维度是5000，但是需要嵌入的维度只有5个，所以截断的位置和x.size(0)一样，即文本条数。



###### 注意力机制

![image-20250425132729612](attention/image-20250425132729612.png)

* ⭐公式：
  ![image-20250425130237450](attention/image-20250425130237450.png)
  * Q：查询向量，Query；
  * K：键向量，Key；
  * V：值向量，Value；
  * 设计思想：利用查询向量Q去匹配相似的键向量K，利用查询到的键向量K得到对应的值向量V
* QK相乘，目的是得到Q和K的相关性，除以dk^(1/2)，目的是为了保证解的稳定性，这个计算出来的值是注意力得分，最后通过softmax选择最大的注意力得分和对应的值向量进行作用，得到注意力得分作用下的值向量；

* 通俗点理解：注意力机制就是找文本之间相关性，QK相乘是点积，回忆点积的作用，点积可以得到相关性。
  ![image-20250425131027518](attention/image-20250425131027518.png)
  * 思考余弦相似度，起作用的正是点积操作；这不正是注意力机制类似吗😀



* 注意力机制整体代码
  ⭐⭐观察张量的维度和流向❗

  ``` python
  import torch
  import torch.nn as nn
  import torch.nn.functional as F
  
  class SingleHeadAttention(nn.Module):
      def __init__(self, d_model):
          super(SingleHeadAttention, self).__init__()
          self.d_model = d_model
          
          # 线性变换矩阵，用于生成查询、键和值
          self.fc_q = nn.Linear(d_model, d_model)
          self.fc_k = nn.Linear(d_model, d_model)
          self.fc_v = nn.Linear(d_model, d_model)
          
          # 输出线性变换矩阵
          self.fc_o = nn.Linear(d_model, d_model)
          
      def forward(self, x, mask=None):
          # 生成查询、键和值
          Q = self.fc_q(q)
          K = self.fc_k(k)
          V = self.fc_v(v)
          
          # 计算注意力分数
          scores = torch.matmul(Q, K.transpose(-1, -2)) / math.sqrt(self.d_model)
          
          # 应用掩码（如果有）
          if mask is not None:
              scores = scores.masked_fill(mask == 0, -1e9)
          
          # 应用softmax函数，将分数转换为概率分布
          attn = F.softmax(scores, dim=-1)
          
          # 计算加权和
          out = torch.matmul(attn, V)
          
          # 应用输出线性变换
          out = self.fc_o(out)
          
          return out
  
  # 示例用法
  if __name__ == "__main__":
      # 初始化单头注意力模块
      attention = SingleHeadAttention(d_model=512)
      
      # 创建随机输入数据
      batch_size = 32
      seq_length = 50
      x = torch.randn(batch_size, seq_length, 512)  # 查询
      
      # 创建掩码（可选）
      mask = None  # 在实际应用中，可以根据需要创建掩码
      
      # 前向传播
      out = attention(q, k, v, mask)
      
      print(out.shape)  # 输出形状：(batch_size, seq_length, d_model)
  ```

* Q\K\V来自于对嵌入向量的投影：
  ``` python
  self.fc_q = nn.Linear(d_model, d_model)
  self.fc_k = nn.Linear(d_model, d_model)
  self.fc_v = nn.Linear(d_model, d_model)
  ```

  * 都是用线性层进行投影的

  

###### 自注意力和注意力机制的区别

- [ ] 自注意力：输入是本身的数据，不包含其他的输入
  用途：可以用于特征增强，计算机视觉里面的；

![image-20250425132800839](attention/image-20250425132800839.png)

- [ ] 注意力机制：输入数据一部分是decoder自己的，一部分是encoder来源；
  用途：GPT生成模型；

![image-20250425132949480](attention/image-20250425132949480.png)



#### 总结

1. 自注意力机制，注意力机制；
2. 编码器解码器架构；
3. 词向量的表示；